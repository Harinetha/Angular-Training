import { Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AwardsComponent } from './awards/awards.component';
import { CocurricularComponent } from './cocurricular/cocurricular.component';
import { EducationComponent } from './education/education.component';
import { SkillsComponent } from './skills/skills.component';
export const Approute: Routes = [
    {
        path: '',
        component: AboutComponent
    },
    {
        path: 'about',
        component: AboutComponent
    },
    {
        path: 'awards',
        component: AwardsComponent
    },
    {
        path: 'cocurricular',
        component: CocurricularComponent
    },
    {
        path: 'education',
        component: EducationComponent
    },
    {
        path: 'skills',
        component: SkillsComponent
    }
]