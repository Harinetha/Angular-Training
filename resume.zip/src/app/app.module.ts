import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { Approute } from './app.route';

import { AboutComponent } from './about/about.component';
import { EducationComponent } from './education/education.component';
import { SkillsComponent } from './skills/skills.component';
import { AwardsComponent } from './awards/awards.component';
import { NavComponent } from './nav/nav.component';
import { CocurricularComponent } from './cocurricular/cocurricular.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    EducationComponent,
    SkillsComponent,
    AwardsComponent,
    NavComponent,
    CocurricularComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(Approute)
  ],

exports: [RouterModule],
providers: [],
bootstrap: [AppComponent]
})
export class AppModule { }

export class AppRoutingModule {
}