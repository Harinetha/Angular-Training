import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cocurricular',
  templateUrl: './cocurricular.component.html',
  styleUrls: ['./cocurricular.component.css']
})
export class CocurricularComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
