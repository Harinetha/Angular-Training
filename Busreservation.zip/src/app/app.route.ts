import {Routes} from '@angular/router';
import { SearchComponent} from './search/search.component';
import {ResultComponent}from './result/result.component';
import {RegisterComponent} from './register/register.component';
import { FormComponent } from './form/form.component';
export const Approute : Routes = [
    {
        path:'',
        component:SearchComponent
    },
    {
        path:'result',
       component:ResultComponent
    },
    {
        path:'register',
       component:RegisterComponent
    },
    {
        path:'form',
        component:FormComponent
    }
     
];
