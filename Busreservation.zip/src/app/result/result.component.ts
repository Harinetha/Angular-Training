import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  Details: any[];
  
  constructor() { 
  
    this.Details =[
      {Transport:'K P N', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Tharai Travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Kongu transport', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'SPBT', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Hari', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Lingan Travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P r', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'vijaya lakshmi travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Raja', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S K S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S R S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Lingam', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P K', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S P M', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'H M S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K S R', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'L R M', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P N', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      
      ]
    }
      getDetails():void{

    this.Details =[
      {Transport:'K P N', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Tharai Travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Kongu transport', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'SPBT', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Hari', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Lingan Travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P r', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'vijaya lakshmi travels', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Raja', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S K S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S R S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Lingam', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P K', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'S P M', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'H M S', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K S R', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'L R M', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'K P N', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'},
      {Transport:'Abi', Departure:'21:30' ,Duration:'08h 00m' ,Arrival:'05:30' ,Rating:'4.8', Fare:'INR 500', SeatsAvailable:'12 seats'}
      
      ]      
  }
 
  ngOnInit() {
  }

}
