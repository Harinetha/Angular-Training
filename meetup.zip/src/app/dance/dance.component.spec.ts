import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DanceComponent } from './dance.component';

describe('DanceComponent', () => {
  let component: DanceComponent;
  let fixture: ComponentFixture<DanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
