import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dance',
  templateUrl: './dance.component.html',
  styleUrls: ['./dance.component.css']
})
export class DanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
