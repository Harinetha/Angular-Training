import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Approute } from './app.route';
import { AppComponent } from './app.component';
import { MeetComponent } from './meet/meet.component';
import { NavComponent } from './nav/nav.component';
import { ArtsComponent } from './arts/arts.component';
import { CareerComponent } from './career/career.component';
import { DanceComponent } from './dance/dance.component';
import { DrinkComponent } from './drink/drink.component';
import { FamilyComponent } from './family/family.component';
import { FilmComponent } from './film/film.component';
import { HealthComponent } from './health/health.component';
import { LearningComponent } from './learning/learning.component';
import { MusicComponent } from './music/music.component';
import { PhotographyComponent } from './photography/photography.component';
import { SocialComponent } from './social/social.component';
import { SportsComponent } from './sports/sports.component';

@NgModule({
  declarations: [
    AppComponent,
    MeetComponent,
    NavComponent,
    ArtsComponent,
    CareerComponent,
    DanceComponent,
    DrinkComponent,
    FamilyComponent,
    FilmComponent,
    HealthComponent,
    LearningComponent,
    MusicComponent,
    PhotographyComponent,
    SocialComponent,
    SportsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(Approute)
  ],
  exports: [RouterModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
