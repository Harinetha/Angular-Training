import {Routes} from '@angular/router';
import { ArtsComponent} from './arts/arts.component';
import { CareerComponent } from './career/career.component';
import { DanceComponent } from './dance/dance.component';
import { DrinkComponent } from './drink/drink.component';
import { FamilyComponent } from './family/family.component';
import { FilmComponent } from './film/film.component';
import { HealthComponent } from './health/health.component';
import { LearningComponent } from './learning/learning.component';
import { MusicComponent } from './music/music.component';
import { PhotographyComponent } from './photography/photography.component';
import { SocialComponent } from './social/social.component';
import { MeetComponent } from './meet/meet.component';

export const Approute : Routes = [
    {
        path:'',
        component:MeetComponent
    },
    {
        path:'arts',
        component:ArtsComponent
    },
    {
        path:'career',
       component:CareerComponent
    },
    {
        path:'dance',
       component:DanceComponent
    },
    {
        path:'drink',
       component:DrinkComponent
    },
    {
        path:'family',
       component:FamilyComponent
    },
    {
        path:'film',
       component:FilmComponent
    },
    {
        path:'health',
       component:HealthComponent
    },
    {
        path:'learning',
       component:LearningComponent
    },
    {
        path:'music',
       component:MusicComponent
    },
    {
        path:'photography',
       component:PhotographyComponent
    },
    {
        path:'social',
       component:SocialComponent
    },
    {
        path:'sports',
       component:SocialComponent
    },
   
    
     
];
