import {Routes} from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import {FlotComponent}from './flot/flot.component';
import{MorrisComponent}from './morris/morris.component';
import{FormsComponent} from './forms/forms.component';
import{PanelComponent} from './panel/panel.component';
import { ButtonComponent } from './button/button.component';
import { NotificationsComponent } from './notifications/notifications.component';
import{TypographyComponent} from './typography/typography.component';
import{IconsComponent} from './icons/icons.component';
import{GridComponent}from './grid/grid.component';
import{BlankComponent}from './blank/blank.component';
import{LoginComponent} from './login/login.component';
import{TablesComponent} from './tables/tables.component'
export const Approute : Routes = [
    {
        path:'',
        component:DashboardComponent
    },
    {
        path:'flot',
       component:FlotComponent
    },
    {
        path:'morris',
       component:MorrisComponent
    },
    {
        path:'tables',
       component:TablesComponent
    },
    {
        path:'forms',
       component:FormsComponent
    },
    {
        path:'panel',
       component:PanelComponent
    },
    {
        path:'button',
       component:ButtonComponent
    },
    {
        path:'notifications',
       component:NotificationsComponent
    },
    {
        path:'typography',
       component:TypographyComponent
    },
    {
        path:'icons',
       component:IconsComponent
    },
    {
        path:'grid',
       component:GridComponent
    },
    {
        path:'blank',
       component:BlankComponent
    },
    {
        path:'login',
       component:LoginComponent
    }
];
