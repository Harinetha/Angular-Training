import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-morris',
  templateUrl: './morris.component.html',
  styleUrls: ['./morris.component.css']
})
export class MorrisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
